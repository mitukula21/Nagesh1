package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Fetch")
public class Fetch extends HttpServlet
{
	private static final long serialVersionUID = 1L;
 
    public Fetch() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
 
		String ID = request.getParameter("id");
		int id = Integer.parseInt(ID);
        
		try { 
			Class.forName("oracle.jdbc.OracleDriver");
		
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
			PreparedStatement ps = con.prepareStatement("select * from businessauto1 where question_id=?");
			ps.setInt(1, id);
 
			ResultSet rs = ps.executeQuery();
 
			while (rs.next()) {
				out.println(
						"Questionid: " + rs.getInt(1) + 
						"</br> question1: "+ rs.getString(2) + "</br> Answer1: " + rs.getString(3)+
						"</br> question2: " + rs.getString(4)+ "</br> Answer2: " + rs.getString(5)+ 
						"</br> question3: " + rs.getString(6)+ "</br> answer3: " + rs.getString(7)+ 
						"</br> question4: " + rs.getString(8)+ "</br> Answer4: " + rs.getString(9)+ 
						"</br> question5: " + rs.getString(10)+ "</br> Answer5: " + rs.getString(11)+ 
						"</br> question6: " + rs.getString(12)+ "</br> Answer6: " + rs.getString(13)+ 
						"</br> question7: " + rs.getString(14)+ "</br> Answer7: " + rs.getString(15));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	
	}
 
}