package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.nag.AccountBean;
import com.nag.BusinessBean;

public class BusinessDAO
{

		
	  public static int addStudent1(BusinessBean bean)
	  {
		  Connection con = null;
		  PreparedStatement pstmt = null;
		  try
		  {
			 
			  con=AccountDB.getConnection(); 
			  
			  String ins_str = 
				  "insert into businessauto1 values(questionid.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			  
			  pstmt = con.prepareStatement(ins_str);
			  String q1="vehicle type";
			  String q2="vehicle model year";
			  String q3="vehicle model";
			  String q4="daily copmmuwe distance";
			  String q5="service center";
			  String q6="collision coverage limit";
			  String q7="bodily injury limit";
			  
			  
			
			  
			  pstmt.setString(1,q1);
			  pstmt.setString(2,bean.getVehicletype());
			  
			  pstmt.setString(3,q2);
			  pstmt.setString(4,bean.getVehiclemy());
			  pstmt.setString(5,q3);
			  
			  pstmt.setString(6,bean.getVehiclemodel());
			  pstmt.setString(7,q4);
			  pstmt.setString(8,bean.getDailycd());
			  pstmt.setString(9,q5);
			  pstmt.setString(10,bean.getServicecenter());
			  pstmt.setString(11,q6);
			  pstmt.setString(12,bean.getLimit());
			  pstmt.setString(13,q7);
			  pstmt.setString(14,bean.getLimit2());
			  
			 
			  
			  
			  int updateCount = pstmt.executeUpdate();
			  
			  con.close();
			  
			  return updateCount;
			  
			  
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
		  
	  }
	}

