package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PolicyCreation extends HttpServlet
{


public  void doGet(HttpServletRequest request,HttpServletResponse response) 
   throws ServletException,IOException 
{
	
	String i=request.getParameter("property and liability");
	int ii=Integer.parseInt(i);
    System.out.println("Your value is "+i);
    String a=request.getParameter("vehicle type");
    int ia=Integer.parseInt(a);
    System.out.println("Your value is "+a);
    String b=request.getParameter("vehicle model year");
    int ib=Integer.parseInt(b);System.out.println("Your value is "+b);
    String c=request.getParameter("vehicle model");
    int ic=Integer.parseInt(c);System.out.println("Your value is "+c);
    String d=request.getParameter("daily commute distance");
    int id=Integer.parseInt(d);System.out.println("Your value is "+d);
    String e=request.getParameter("service centre");
    int ie=Integer.parseInt(e);System.out.println("Your value is "+e);
    String f=request.getParameter("collision coverage limit");
    int intf=Integer.parseInt(f);System.out.println("Your value is "+f);
    String g=request.getParameter("uninsured motorist");
    int ig=Integer.parseInt(g);System.out.println("Your value is "+g);
    String h=request.getParameter("unknown hit or theft coverage");
    int ih=Integer.parseInt(h);System.out.println("Your value is "+h);
     int sum=ii+ia+ib+ic+id+ie+intf+ig+ih;
    System.out.println(sum);
}
}
